I welcome any and all suggestions!

# Suggesting new commands
Please open an issue/pull request that uses the following format to describe your command:
| Op | Description | Stack (before) | Stack (after) | Notes |
| -- | ----------- | -------------- | ------------- | ----- |
| `x` | Does x | `[a, b, c]` | `[x, a, b, c]` | Details |

This is for ease of implementation and documentation.
